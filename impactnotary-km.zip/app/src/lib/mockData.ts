import type { ScoreRecord, NotablePR, ScoreBreakdown, BotCheckResult } from '@/types';

// --- Weighted Scoring Algorithm ---
// Score = (Stars * 0.35) + (Forks * 0.15) + (Merged_PRs * 0.25) + (Issue_Engagement * 0.15) + (Repo_Age_Factor * 0.10)
// Normalized to 0-100 scale with velocity penalty

export function calculateScore(
  total_stars: number,
  total_forks: number,
  prs_merged: number,
  issues_participated: number,
  account_age_months: number,
  activity_velocity: number
): { score: number; breakdown: ScoreBreakdown } {
  const stars_component = Math.min(total_stars * 0.35, 35);
  const forks_component = Math.min(total_forks * 0.15, 15);
  const prs_component = Math.min(prs_merged * 0.25, 25);
  const issues_component = Math.min(issues_participated * 0.15, 15);
  const age_component = Math.min(account_age_months * 0.10, 10);

  const raw_total = stars_component + forks_component + prs_component + issues_component + age_component;

  // Velocity penalty: if velocity > 200 (bursty), apply up to 15% penalty
  let velocity_penalty = 0;
  if (activity_velocity > 200) {
    velocity_penalty = Math.min((activity_velocity - 200) * 0.0015, 15);
  }

  const total = Math.max(0, Math.round(raw_total - velocity_penalty));

  return {
    score: Math.min(100, total),
    breakdown: {
      stars_component: Math.round(stars_component * 10) / 10,
      forks_component: Math.round(forks_component * 10) / 10,
      prs_component: Math.round(prs_component * 10) / 10,
      issues_component: Math.round(issues_component * 10) / 10,
      age_component: Math.round(age_component * 10) / 10,
      velocity_penalty: Math.round(velocity_penalty * 10) / 10,
      total: Math.min(100, total),
    },
  };
}

export function getImpactLevel(score: number): ScoreRecord['impact_level'] {
  if (score >= 90) return 'Elite';
  if (score >= 75) return 'Strong';
  if (score >= 55) return 'Active';
  if (score >= 35) return 'Emerging';
  return 'Novice';
}

export function checkBotProofing(
  account_age_months: number,
  activity_velocity: number
): BotCheckResult {
  const account_age_ok = account_age_months >= 1;
  const velocity_ok = activity_velocity <= 200;

  const details: string[] = [];
  if (!account_age_ok) details.push(`Account age ${account_age_months}mo < 1mo minimum`);
  if (!velocity_ok) details.push(`Velocity ${activity_velocity} commits/mo suggests burst activity`);

  return {
    passed: account_age_ok && velocity_ok,
    account_age_ok,
    velocity_ok,
    details: details.length > 0 ? details.join('; ') : 'All checks passed',
  };
}

// --- Notable PRs ---
function makePRs(username: string, repos: string[]): NotablePR[] {
  const templates: Record<string, NotablePR[]> = {
    torvalds: [
      { repo_name: 'linux', title: 'Merge tag v6.8-rc1', description: 'Merged 15,000+ commits across 5,000 files for the 6.8 kernel release cycle', merged_at: '2024-02-15', additions: 482000, deletions: 312000, impact_tag: 'Systems Impact' },
      { repo_name: 'linux', title: 'Refactor scheduler load balancing', description: 'Improved CPU scheduling fairness across NUMA nodes reducing latency by 18%', merged_at: '2023-11-08', additions: 12400, deletions: 8900, impact_tag: 'Performance' },
      { repo_name: 'libgit2', title: 'Add sparse-checkout support', description: 'Enabled partial clone workflows for monorepos, adopted by GitHub and GitLab', merged_at: '2023-09-22', additions: 8400, deletions: 1200, impact_tag: 'Tooling' },
      { repo_name: 'linux', title: 'BPF subsystem hardening', description: 'Security patches for eBPF verifier preventing potential privilege escalation', merged_at: '2024-01-10', additions: 6200, deletions: 3100, impact_tag: 'Security' },
      { repo_name: 'linux', title: 'DRM driver updates for Intel Arc', description: 'Added support for new Intel Arc GPU generation in kernel display subsystem', merged_at: '2023-12-05', additions: 15200, deletions: 4300, impact_tag: 'Hardware Support' },
    ],
    facebook: [
      { repo_name: 'react', title: 'React Compiler (React Forget)', description: 'Automatic memoization compiler eliminating manual useMemo/useCallback', merged_at: '2024-02-20', additions: 89000, deletions: 12000, impact_tag: 'Core Framework' },
      { repo_name: 'pytorch', title: 'torch.compile 2.0 production release', description: 'Full-graph compilation with Triton kernels, 43% speedup on average', merged_at: '2023-12-18', additions: 124000, deletions: 34000, impact_tag: 'AI Infrastructure' },
      { repo_name: 'react', title: 'Server Actions stable release', description: 'Form mutations and data updates without client-side JavaScript', merged_at: '2024-03-01', additions: 34000, deletions: 8000, impact_tag: 'Full Stack' },
      { repo_name: 'pytorch', title: 'DTensor sharding strategies', description: 'Distributed tensor parallelism for large model training across GPUs', merged_at: '2024-01-25', additions: 56000, deletions: 12000, impact_tag: 'Distributed Systems' },
      { repo_name: 'react', title: 'Offscreen component preservation', description: 'Background tab state preservation enabling instant tab switching', merged_at: '2023-10-14', additions: 18000, deletions: 4300, impact_tag: 'UX Engineering' },
    ],
    microsoft: [
      { repo_name: 'vscode', title: 'AI-powered inline completions', description: 'Integrated Copilot completions directly into the editor core with sub-50ms latency', merged_at: '2024-01-30', additions: 42000, deletions: 8000, impact_tag: 'AI Integration' },
      { repo_name: 'typescript', title: 'Type inference engine rewrite', description: 'New constraint solver reducing type-checking time by 35% on large codebases', merged_at: '2024-02-10', additions: 78000, deletions: 45000, impact_tag: 'Compiler' },
      { repo_name: 'vscode', title: 'Remote Development over SSH', description: 'Full workspace development on remote servers without local sync', merged_at: '2023-09-10', additions: 65000, deletions: 15000, impact_tag: 'DevEx' },
      { repo_name: 'playwright', title: 'Trace viewer with timeline', description: 'Visual test debugging with screenshot timeline and network waterfall', merged_at: '2023-11-20', additions: 34000, deletions: 6000, impact_tag: 'Testing' },
      { repo_name: 'typescript', title: 'Decorators stage 3 support', description: 'TC39 stage 3 decorators with full type inference and metadata', merged_at: '2024-03-05', additions: 28000, deletions: 11000, impact_tag: 'Language Features' },
    ],
    google: [
      { repo_name: 'tensorflow', title: 'XLA GPU fusion optimizations', description: 'Automatic kernel fusion reducing GPU memory bandwidth by 40%', merged_at: '2024-01-18', additions: 45000, deletions: 12000, impact_tag: 'AI Performance' },
      { repo_name: 'golang', title: 'Profile-guided optimization', description: 'PGO in Go 1.21 delivering 2-7% performance improvement across benchmarks', merged_at: '2023-08-15', additions: 18000, deletions: 4000, impact_tag: 'Compiler' },
      { repo_name: 'angular', title: 'Signals-based reactivity', description: 'Fine-grained reactive primitives replacing Zone.js with 3x faster change detection', merged_at: '2024-02-05', additions: 56000, deletions: 18000, impact_tag: 'Core Rewrite' },
      { repo_name: 'tensorflow', title: 'TF-Distributed Sharding API', description: 'Unified API for model parallelism across TPU pods', merged_at: '2023-12-12', additions: 67000, deletions: 21000, impact_tag: 'Scale' },
      { repo_name: 'golang', title: 'Structured logging (slog)', description: 'Standard library structured logging with JSON handler and context propagation', merged_at: '2023-10-01', additions: 12000, deletions: 2000, impact_tag: 'Standard Library' },
    ],
    vercel: [
      { repo_name: 'next.js', title: 'Server Actions v2 with streaming', description: 'Streaming responses from server actions enabling real-time UI updates', merged_at: '2024-02-28', additions: 28000, deletions: 6000, impact_tag: 'Full Stack' },
      { repo_name: 'turborepo', title: 'Remote caching v3', description: 'Distributed task caching with Vercel edge, reducing CI times by 85%', merged_at: '2024-01-15', additions: 34000, deletions: 9000, impact_tag: 'Build Systems' },
      { repo_name: 'next.js', title: 'Partial Prerendering (PPR)', description: 'Static shell with dynamic streaming, combining SSG and SSR benefits', merged_at: '2024-03-10', additions: 42000, deletions: 11000, impact_tag: 'Rendering' },
      { repo_name: 'swc', title: 'CSS Modules tree-shaking', description: 'Compile-time unused CSS elimination reducing bundle sizes by 20-40%', merged_at: '2023-11-25', additions: 18000, deletions: 3400, impact_tag: 'CSS' },
      { repo_name: 'next.js', title: 'Turbopack beta stability', description: 'Webpack replacement with 10x faster HMR and 3x faster production builds', merged_at: '2024-01-05', additions: 89000, deletions: 12000, impact_tag: 'Bundler' },
    ],
    'rust-lang': [
      { repo_name: 'rust', title: 'Async fn in traits (AFIT)', description: 'Native async functions in traits without boxing, stabilized in Rust 1.75', merged_at: '2023-12-28', additions: 34000, deletions: 8000, impact_tag: 'Language Feature' },
      { repo_name: 'rust', title: 'Const generics stabilization', description: 'Generic parameters over constant values, enabling compile-time array sizes', merged_at: '2023-09-20', additions: 28000, deletions: 14000, impact_tag: 'Type System' },
      { repo_name: 'cargo', title: 'Sparse registry protocol', description: 'HTTP-based crate index reducing fresh install times by 60%', merged_at: '2023-10-15', additions: 12000, deletions: 3000, impact_tag: 'Tooling' },
      { repo_name: 'rust', title: 'LLD as default linker', description: 'Switched to LLVM linker reducing link times by 30% on large projects', merged_at: '2024-02-01', additions: 8000, deletions: 2200, impact_tag: 'Toolchain' },
      { repo_name: 'rust-analyzer', title: 'Type inference for closures', description: 'Full type inference for complex closure chains in IDE', merged_at: '2024-01-20', additions: 15000, deletions: 3800, impact_tag: 'IDE' },
    ],
    'oven-sh': [
      { repo_name: 'bun', title: 'Bun v1.0 release', description: 'All-in-one JavaScript runtime with 3x faster startup than Node.js', merged_at: '2023-09-08', additions: 180000, deletions: 45000, impact_tag: 'Runtime' },
      { repo_name: 'bun', title: 'Bun bundler with tree-shaking', description: 'Built-in bundler replacing esbuild with CSS import support', merged_at: '2024-02-14', additions: 67000, deletions: 12000, impact_tag: 'Bundler' },
      { repo_name: 'bun', title: 'SQLite embedded driver', description: 'Native SQLite client with 4x better performance than better-sqlite3', merged_at: '2024-01-22', additions: 34000, deletions: 6000, impact_tag: 'Database' },
      { repo_name: 'bun', title: 'Windows port', description: 'Full Windows support with IOCP-based event loop', merged_at: '2024-03-15', additions: 89000, deletions: 23000, impact_tag: 'Platform Support' },
    ],
    tailwindlabs: [
      { repo_name: 'tailwindcss', title: 'Tailwind CSS v4.0 engine rewrite', description: 'Rust-powered CSS engine with 10x faster compilation and zero config', merged_at: '2024-03-20', additions: 120000, deletions: 45000, impact_tag: 'Core Rewrite' },
      { repo_name: 'headlessui', title: 'React Aria compatibility layer', description: 'Accessible component primitives with full WAI-ARIA compliance', merged_at: '2024-01-10', additions: 34000, deletions: 8000, impact_tag: 'Accessibility' },
      { repo_name: 'tailwindcss', title: 'Container queries plugin', description: 'Native CSS container queries with responsive utility classes', merged_at: '2023-10-30', additions: 12000, deletions: 2100, impact_tag: 'Responsive Design' },
      { repo_name: 'tailwindcss', title: 'Dark mode strategy overhaul', description: 'Class-based dark mode with CSS variables and color-mix support', merged_at: '2024-02-08', additions: 18000, deletions: 5400, impact_tag: 'Theming' },
    ],
    sindresorhus: [
      { repo_name: 'awesome', title: 'Curated list standardization', description: 'Established the gold standard for curated resource lists across all programming languages', merged_at: '2024-01-01', additions: 2800, deletions: 1200, impact_tag: 'Community' },
      { repo_name: 'clipboardy', title: 'Cross-platform clipboard rewrite', description: 'Unified clipboard API working on macOS, Linux, and Windows without external deps', merged_at: '2023-09-15', additions: 5600, deletions: 1800, impact_tag: 'Tooling' },
      { repo_name: 'got', title: 'HTTP/2 and cache support', description: 'Built-in HTTP/2 and RFC-compliant cache support for Node.js HTTP client', merged_at: '2023-11-10', additions: 22000, deletions: 6700, impact_tag: 'Networking' },
      { repo_name: 'execa', title: 'Process execution modernized', description: 'Modern child_process replacement with promise API and cross-platform support', merged_at: '2024-02-01', additions: 12000, deletions: 3400, impact_tag: 'Tooling' },
      { repo_name: 'ow', title: 'TypeScript-first argument validation', description: 'Function argument validation with 200+ built-in predicates and TS inference', merged_at: '2023-12-05', additions: 8900, deletions: 2100, impact_tag: 'Type Safety' },
    ],
    prisma: [
      { repo_name: 'prisma', title: 'Accelerate connection pooler', description: 'Edge-compatible connection pooler with sub-5ms query latency', merged_at: '2024-02-25', additions: 34000, deletions: 8000, impact_tag: 'Database' },
      { repo_name: 'prisma', title: 'TypedSQL raw queries', description: 'Type-safe raw SQL queries with automatic type generation from query analysis', merged_at: '2024-01-18', additions: 28000, deletions: 6700, impact_tag: 'Type Safety' },
      { repo_name: 'prisma', title: 'PostgreSQL extensions support', description: 'pgvector, PostGIS, and custom extension support in schema definition', merged_at: '2023-11-22', additions: 18000, deletions: 4500, impact_tag: 'Database Features' },
      { repo_name: 'prisma', title: 'Pulse real-time streaming', description: 'Database change event streaming for real-time application updates', merged_at: '2024-03-08', additions: 42000, deletions: 12000, impact_tag: 'Real-time' },
    ],
    shadcn: [
      { repo_name: 'ui', title: 'Radix UI v2 migration', description: 'Updated all 30+ components to Radix UI v2 with improved accessibility', merged_at: '2024-02-15', additions: 18000, deletions: 9000, impact_tag: 'Component Library' },
      { repo_name: 'ui', title: 'CSS variables theming system', description: 'Zero-JS theming with CSS variables and dark mode support', merged_at: '2024-01-20', additions: 12000, deletions: 3400, impact_tag: 'Theming' },
      { repo_name: 'next-template', title: 'App Router template overhaul', description: 'Production-ready Next.js 14 template with authentication and database', merged_at: '2024-03-01', additions: 8000, deletions: 2100, impact_tag: 'Templates' },
      { repo_name: 'ui', title: 'New York style variant', description: 'Alternative component style variant with different design language', merged_at: '2023-12-10', additions: 15000, deletions: 2000, impact_tag: 'Design System' },
    ],
    tannerlinsley: [
      { repo_name: 'tanstack-query', title: 'v5 rewrite with signals', description: 'Signal-based reactivity with 40% smaller bundle and automatic garbage collection', merged_at: '2024-02-20', additions: 89000, deletions: 56000, impact_tag: 'Core Rewrite' },
      { repo_name: 'tanstack-table', title: 'Virtual scrolling v2', description: 'Built-in row virtualization supporting 100K+ rows with smooth scrolling', merged_at: '2024-01-15', additions: 28000, deletions: 9000, impact_tag: 'Performance' },
      { repo_name: 'tanstack-router', title: 'Type-safe search params', description: 'Full TypeScript inference for URL search parameters with validation', merged_at: '2024-03-05', additions: 34000, deletions: 11000, impact_tag: 'Type Safety' },
      { repo_name: 'tanstack-query', title: 'Suspense integration stable', description: 'React Suspense-first data fetching with automatic error boundaries', merged_at: '2023-11-20', additions: 22000, deletions: 6700, impact_tag: 'React Integration' },
      { repo_name: 'tanstack-form', title: 'Headless form library', description: 'Framework-agnostic form management with headless UI primitives', merged_at: '2024-02-01', additions: 45000, deletions: 12000, impact_tag: 'Forms' },
    ],
    kentcdodds: [
      { repo_name: 'react-testing-library', title: 'v14 with user-event v14', description: 'Modern interaction testing with pointer events and keyboard simulation', merged_at: '2024-01-25', additions: 22000, deletions: 8000, impact_tag: 'Testing' },
      { repo_name: 'epicweb-dev', title: 'Full-stack workshop platform', description: 'Interactive learning platform for web development with progressive enhancement', merged_at: '2024-03-10', additions: 67000, deletions: 12000, impact_tag: 'Education' },
      { repo_name: 'remix', title: 'Nested routing improvements', description: 'Parallel route fetching and error boundary isolation per route segment', merged_at: '2024-02-05', additions: 34000, deletions: 8900, impact_tag: 'Framework' },
      { repo_name: 'react-testing-library', title: 'Async utilities overhaul', description: 'waitFor and findBy improvements with automatic act() wrapping', merged_at: '2023-12-15', additions: 12000, deletions: 4500, impact_tag: 'Testing' },
    ],
    jaredpalmer: [
      { repo_name: 'turborepo', title: 'V2 task graph engine', description: 'Rewritten task scheduler with topological sort and parallel execution', merged_at: '2024-01-30', additions: 56000, deletions: 18000, impact_tag: 'Build System' },
      { repo_name: 'formik', title: 'v3 React 18 concurrent mode', description: 'Full concurrent features support with useTransition integration', merged_at: '2024-02-15', additions: 18000, deletions: 9000, impact_tag: 'React' },
      { repo_name: 'turborepo', title: 'Watch mode implementation', description: 'Filesystem watcher for incremental rebuilds with debounced task scheduling', merged_at: '2023-12-20', additions: 34000, deletions: 8900, impact_tag: 'DevEx' },
      { repo_name: 'tsdx', title: 'Zero-config TypeScript bundler', description: 'TypeScript package development tool with Rollup and Jest preconfigured', merged_at: '2023-10-01', additions: 12000, deletions: 3400, impact_tag: 'Tooling' },
    ],
    mxstbr: [
      { repo_name: 'styled-components', title: 'v6 with CSS nesting', description: 'Native CSS nesting support and 50% smaller runtime with stylis v4', merged_at: '2024-02-01', additions: 28000, deletions: 12000, impact_tag: 'CSS-in-JS' },
      { repo_name: 'react-boilerplate', title: 'Next.js migration guide', description: 'Official migration path from custom boilerplate to Next.js App Router', merged_at: '2024-01-15', additions: 8000, deletions: 5600, impact_tag: 'Community' },
      { repo_name: 'styled-components', title: 'React Native stylesheet fix', description: 'Fixed cascading stylesheet issues in React Native with platform detection', merged_at: '2023-11-20', additions: 12000, deletions: 3400, impact_tag: 'React Native' },
      { repo_name: 'react-boilerplate', title: 'PWA offline support', description: 'Service worker integration with offline-first caching strategy', merged_at: '2023-10-15', additions: 6700, deletions: 1800, impact_tag: 'PWA' },
    ],
  };

  return templates[username] || [
    { repo_name: repos[0] || 'main-project', title: 'Core feature implementation', description: `Major feature contribution to ${repos[0] || 'the main repository'}`, merged_at: '2024-02-01', additions: 12000, deletions: 3400, impact_tag: 'Feature' },
    { repo_name: repos[0] || 'main-project', title: 'Performance optimization', description: 'Improved rendering and bundle performance across the codebase', merged_at: '2024-01-15', additions: 8900, deletions: 2100, impact_tag: 'Performance' },
    { repo_name: repos[1] || 'side-project', title: 'Bug fix series', description: 'Resolved 15+ critical issues reported by the community', merged_at: '2023-12-20', additions: 5600, deletions: 1800, impact_tag: 'Stability' },
    { repo_name: repos[2] || 'docs-site', title: 'Documentation overhaul', description: 'Rewrote API documentation with interactive examples and TypeScript types', merged_at: '2024-03-01', additions: 15000, deletions: 3400, impact_tag: 'Documentation' },
  ];
}

// --- Mock Score Records ---
function buildRecord(
  username: string,
  repos: number,
  stars: number,
  forks: number,
  events: number,
  prs: number,
  issues: number,
  ageMonths: number,
  velocity: number,
  strengths: string,
  repoNames: string,
  summary: string
): ScoreRecord {
  const botCheck = checkBotProofing(ageMonths, velocity);
  const { score } = calculateScore(stars, forks, prs, issues, ageMonths, velocity);
  const level = getImpactLevel(score);
  const prs_data = makePRs(username, repoNames.split(',').map(r => r.trim()));

  return {
    github_username: username,
    contribution_score: score,
    impact_level: botCheck.passed ? level : 'Invalid',
    repo_count: repos,
    total_stars: stars,
    total_forks: forks,
    public_events: events,
    prs_merged: prs,
    issues_participated: issues,
    account_age_months: ageMonths,
    activity_velocity: velocity,
    activity_velocity_flag: !botCheck.velocity_ok,
    key_strengths: strengths,
    notable_repos: repoNames,
    notable_prs: prs_data,
    activity_summary: summary,
    is_valid_user: botCheck.passed,
    error_reason: botCheck.passed ? '' : botCheck.details,
    verified_at: '2024-03-25T10:30:00Z',
    verifier: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
  };
}

const MOCK_SCORES: ScoreRecord[] = [
  buildRecord('torvalds', 4, 585000, 52500, 32, 450, 180, 192, 45, 'systems-level impact, community trust, long-term consistency', 'linux, libgit2', 'Creator of Linux kernel with massive global adoption and sustained influence over decades.'),
  buildRecord('facebook', 189, 720000, 145000, 450, 3800, 920, 168, 78, 'ecosystem building, open source leadership, scale', 'react, pytorch', 'Meta Open Source maintains foundational tools used by millions of developers worldwide.'),
  buildRecord('microsoft', 512, 890000, 210000, 890, 5200, 1350, 216, 95, 'enterprise scale, developer tooling, cloud infrastructure', 'vscode, typescript', 'Microsoft Open Source powers modern development with TypeScript, VS Code, and Azure tools.'),
  buildRecord('google', 423, 650000, 180000, 720, 4100, 1080, 192, 82, 'infrastructure scale, AI research, language design', 'tensorflow, golang', 'Google Open Source drives AI innovation with TensorFlow and Go programming language.'),
  buildRecord('vercel', 56, 340000, 62000, 180, 1850, 420, 108, 68, 'developer experience, frontend innovation, deployment revolution', 'next.js, turborepo', 'Pioneering the future of web deployment with Next.js and serverless infrastructure.'),
  buildRecord('rust-lang', 78, 95000, 12000, 240, 2100, 680, 156, 52, 'language design, memory safety, community governance', 'rust, cargo', 'The Rust Programming Language team builds the most loved programming language with rigorous engineering.'),
  buildRecord('sindresorhus', 1200, 180000, 12000, 320, 3400, 850, 156, 72, 'prolific output, npm ecosystem, developer tooling', 'awesome, clipboardy', 'Sindre Sorhus is one of the most prolific open source contributors with over 1000 npm packages.'),
  buildRecord('tailwindlabs', 24, 98000, 5200, 110, 920, 340, 96, 55, 'CSS framework innovation, design system thinking, developer productivity', 'tailwindcss, headlessui', 'Tailwind CSS revolutionized utility-first CSS and modern web design workflows.'),
  buildRecord('oven-sh', 12, 72000, 2800, 85, 680, 220, 36, 92, 'JavaScript runtime innovation, performance optimization, developer tooling', 'bun', 'Bun is an all-in-one JavaScript runtime that is dramatically faster than Node.js and Deno.'),
  buildRecord('tannerlinsley', 45, 85000, 5200, 140, 1650, 480, 132, 58, 'data fetching innovation, React ecosystem, open source sustainability', 'tanstack-query, tanstack-table', 'Creator of TanStack Query, the async state management library used by millions of React developers.'),
  buildRecord('prisma', 34, 42000, 1800, 95, 780, 310, 96, 48, 'database tooling, type safety, developer experience', 'prisma, prisma-client-js', 'Prisma is the next-generation ORM for Node.js and TypeScript with type-safe database access.'),
  buildRecord('kentcdodds', 156, 52000, 8500, 200, 1450, 620, 144, 62, 'testing education, React patterns, community teaching', 'react-testing-library, epicweb-dev', 'Kent C. Dodds is a world-renowned educator and creator of Testing Library with massive community impact.'),
  buildRecord('shadcn', 8, 78000, 4500, 65, 520, 180, 24, 85, 'component architecture, design system, React ecosystem', 'ui, next-template', 'shadcn/ui redefined how developers build beautiful accessible components in React applications.'),
  buildRecord('jaredpalmer', 28, 38000, 2100, 75, 820, 260, 120, 44, 'build tooling, monorepo management, developer productivity', 'turborepo, formik', 'Creator of Formik and former VP of Vercel Engineering, now building AI infrastructure.'),
  buildRecord('mxstbr', 52, 28000, 1800, 60, 680, 220, 108, 38, 'community building, styled-components, open source advocacy', 'styled-components, react-boilerplate', 'Max Stoiber created styled-components and has been a vocal advocate for open source sustainability.'),
];

const MOCK_INVALID: ScoreRecord[] = [
  {
    github_username: 'fakeuser123456789',
    contribution_score: 0,
    impact_level: 'Invalid',
    repo_count: 0,
    total_stars: 0,
    total_forks: 0,
    public_events: 0,
    prs_merged: 0,
    issues_participated: 0,
    account_age_months: 0,
    activity_velocity: 0,
    activity_velocity_flag: false,
    key_strengths: '',
    notable_repos: '',
    notable_prs: [],
    activity_summary: '',
    is_valid_user: false,
    error_reason: 'GitHub user not found (404)',
    verified_at: '2024-03-20T09:00:00Z',
    verifier: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
  },
  {
    github_username: 'bot_spammer_2024',
    contribution_score: 0,
    impact_level: 'Invalid',
    repo_count: 2,
    total_stars: 0,
    total_forks: 0,
    public_events: 0,
    prs_merged: 0,
    issues_participated: 0,
    account_age_months: 0,
    activity_velocity: 0,
    activity_velocity_flag: true,
    key_strengths: '',
    notable_repos: '',
    notable_prs: [],
    activity_summary: '',
    is_valid_user: false,
    error_reason: 'Bot detected: account age 0 months (minimum 1 month); velocity 340 commits/mo suggests burst activity',
    verified_at: '2024-03-22T14:00:00Z',
    verifier: '0x8ba1f109551bD432803012645Hac136c82C3e5C7',
  },
];

const VERIFIERS = [
  '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
  '0x8ba1f109551bD432803012645Hac136c82C3e5C7',
  '0x3f5CE5FBFe3E9af3971dD833D26bA9b5C936f0bE',
];

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockContract = {
  async getScore(username: string): Promise<ScoreRecord | null> {
    await delay(600);
    const all = [...MOCK_SCORES, ...MOCK_INVALID];
    return all.find(s => s.github_username.toLowerCase() === username.toLowerCase()) || null;
  },

  async getLeaderboard(topN: number = 10): Promise<ScoreRecord[]> {
    await delay(800);
    const sorted = [...MOCK_SCORES]
      .sort((a, b) => b.contribution_score - a.contribution_score)
      .slice(0, topN);
    return sorted.map((s, i) => ({ ...s, rank: i + 1 }));
  },

  async getAllScores(): Promise<ScoreRecord[]> {
    await delay(700);
    return [...MOCK_SCORES, ...MOCK_INVALID];
  },

  async getVerifiers(): Promise<string[]> {
    await delay(300);
    return VERIFIERS;
  },

  async verifyGitHubUser(username: string): Promise<ScoreRecord> {
    await delay(2000);
    const existing = await this.getScore(username);
    if (existing) return existing;

    const score = Math.floor(Math.random() * 50) + 20;
    const prs = Math.floor(Math.random() * 80) + 5;
    const issues = Math.floor(Math.random() * 40) + 3;
    const age = Math.floor(Math.random() * 48) + 3;
    const velocity = Math.floor(Math.random() * 40) + 5;
    const level = getImpactLevel(score);
    const botCheck = checkBotProofing(age, velocity);

    return {
      github_username: username,
      contribution_score: botCheck.passed ? score : 0,
      impact_level: botCheck.passed ? level : 'Invalid',
      repo_count: Math.floor(Math.random() * 30) + 1,
      total_stars: Math.floor(Math.random() * 5000),
      total_forks: Math.floor(Math.random() * 800),
      public_events: Math.floor(Math.random() * 100),
      prs_merged: prs,
      issues_participated: issues,
      account_age_months: age,
      activity_velocity: velocity,
      activity_velocity_flag: !botCheck.velocity_ok,
      key_strengths: 'contributing, learning, growing',
      notable_repos: 'various-projects',
      notable_prs: makePRs(username, ['project-a', 'project-b', 'project-c']),
      activity_summary: `An active developer with a growing presence in the open source community.`,
      is_valid_user: botCheck.passed,
      error_reason: botCheck.passed ? '' : botCheck.details,
      verified_at: new Date().toISOString(),
      verifier: VERIFIERS[0],
    };
  },

  async validateGitHubUser(username: string): Promise<boolean> {
    await delay(400);
    const blocked = ['admin', 'root', 'test', 'user', 'github', 'null', 'undefined', 'bot'];
    if (blocked.includes(username.toLowerCase())) return false;
    if (username.length < 2) return false;
    return true;
  },
};

// --- UI Helpers ---
export function getImpactColor(level: string): string {
  switch (level) {
    case 'Elite': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
    case 'Strong': return 'text-teal-400 bg-teal-400/10 border-teal-400/20';
    case 'Active': return 'text-cyan-400 bg-cyan-400/10 border-cyan-400/20';
    case 'Emerging': return 'text-blue-400 bg-blue-400/10 border-blue-400/20';
    case 'Novice': return 'text-slate-400 bg-slate-400/10 border-slate-400/20';
    case 'Invalid': return 'text-red-400 bg-red-400/10 border-red-400/20';
    default: return 'text-slate-400 bg-slate-400/10 border-slate-400/20';
  }
}

export function getScoreColor(score: number): string {
  if (score >= 90) return 'text-emerald-400';
  if (score >= 75) return 'text-teal-400';
  if (score >= 55) return 'text-cyan-400';
  if (score >= 35) return 'text-blue-400';
  return 'text-slate-400';
}

export function getScoreBarColor(score: number): string {
  if (score >= 90) return 'bg-emerald-400';
  if (score >= 75) return 'bg-teal-400';
  if (score >= 55) return 'bg-cyan-400';
  if (score >= 35) return 'bg-blue-400';
  return 'bg-slate-400';
}

export function getVelocityColor(velocity: number): string {
  if (velocity <= 50) return 'text-emerald-400';
  if (velocity <= 100) return 'text-teal-400';
  if (velocity <= 150) return 'text-cyan-400';
  if (velocity <= 200) return 'text-yellow-400';
  return 'text-red-400';
}

export function getVelocityLabel(velocity: number): string {
  if (velocity <= 50) return 'Organic';
  if (velocity <= 100) return 'Active';
  if (velocity <= 150) return 'Very Active';
  if (velocity <= 200) return 'Intense';
  return 'Bursty (Flagged)';
}
