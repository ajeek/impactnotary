export interface NotablePR {
  repo_name: string;
  title: string;
  description: string;
  merged_at: string;
  additions: number;
  deletions: number;
  impact_tag: string;
}

export interface ScoreRecord {
  github_username: string;
  contribution_score: number;
  impact_level: 'Novice' | 'Emerging' | 'Active' | 'Strong' | 'Elite' | 'Invalid';
  repo_count: number;
  total_stars: number;
  total_forks: number;
  public_events: number;
  prs_merged: number;
  issues_participated: number;
  account_age_months: number;
  activity_velocity: number;
  activity_velocity_flag: boolean;
  key_strengths: string;
  notable_repos: string;
  notable_prs: NotablePR[];
  activity_summary: string;
  is_valid_user: boolean;
  error_reason: string;
  verified_at: string;
  verifier: string;
  rank?: number;
}

export interface ScoreBreakdown {
  stars_component: number;
  forks_component: number;
  prs_component: number;
  issues_component: number;
  age_component: number;
  velocity_penalty: number;
  total: number;
}

export interface BotCheckResult {
  passed: boolean;
  account_age_ok: boolean;
  velocity_ok: boolean;
  details: string;
}

export interface VerificationStatus {
  status: 'pending' | 'proposing' | 'committing' | 'revealing' | 'accepted' | 'finalized' | 'error';
  message: string;
  progress: number;
}

export type ImpactLevel = ScoreRecord['impact_level'];
