import { motion } from 'framer-motion';
import { BookOpen, Code, Shield, Cpu, AlertTriangle, XCircle, ExternalLink, Zap, TrendingUp, Clock, GitPullRequest, Star, GitFork, MessageSquare } from 'lucide-react';
import { useState } from 'react';

const sections = [
  {
    id: 'overview',
    icon: BookOpen,
    title: 'Overview',
    content: (
      <div className="space-y-4">
        <p>Impact Notary is a <strong>GenLayer Intelligent Contract</strong> that verifies GitHub developer reputations through <strong>weighted AI-powered consensus</strong>. Unlike traditional systems that count commits or stars, we evaluate <strong>real impact</strong> using a weighted formula that emphasizes quality signals over vanity metrics.</p>
        <p>The system is publicly searchable — <strong>anyone can verify any GitHub username</strong> without OAuth or account ownership. The goal is recruiter transparency, not identity verification. You cannot fake your score because all scoring happens inside the Intelligent Contract with bot-proofing checks.</p>
        <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
          <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2"><Zap className="h-4 w-4 text-primary" />Key Innovation: Weighted Score Stability Consensus</h4>
          <p className="text-sm text-muted-foreground">All validators re-run the <strong>exact same weighted evaluation function</strong>. The same deterministic formula + same API data = naturally stable outputs. Consensus checks that weighted scores agree within ±5 points and bot-proofing results match.</p>
        </div>
      </div>
    ),
  },
  {
    id: 'scoring',
    icon: TrendingUp,
    title: 'Weighted Scoring',
    content: (
      <div className="space-y-4">
        <p>We avoid "repo counting." Each metric is weighted by its signal quality for real developer impact:</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 my-6">
          {[
            { factor: 'Stars', weight: '35%', icon: Star, desc: 'Public code validation', color: 'text-yellow-400' },
            { factor: 'Merged PRs', weight: '25%', icon: GitPullRequest, desc: 'Collaborative quality', color: 'text-emerald-400' },
            { factor: 'Forks', weight: '15%', icon: GitFork, desc: 'Building on work', color: 'text-blue-400' },
            { factor: 'Issue Engagement', weight: '15%', icon: MessageSquare, desc: 'Community participation', color: 'text-purple-400' },
            { factor: 'Repo Age', weight: '10%', icon: Clock, desc: 'Long-term consistency', color: 'text-cyan-400' },
          ].map((w) => (
            <div key={w.factor} className="rounded-lg border border-border bg-card p-4 text-center">
              <div className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/20 mb-2">
                <w.icon className="h-4 w-4 text-primary" />
              </div>
              <div className={`text-lg font-bold ${w.color}`}>{w.weight}</div>
              <div className="text-xs font-medium text-foreground">{w.factor}</div>
              <div className="text-[10px] text-muted-foreground mt-1">{w.desc}</div>
            </div>
          ))}
        </div>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Python Formula</h4>
        <div className="rounded-lg bg-secondary/50 border border-border p-4">
          <pre className="text-xs text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">{`def calculate_score(total_stars, total_forks, prs_merged, 
                    issues_participated, account_age_months, 
                    activity_velocity):
    stars_component = min(total_stars * 0.35, 35)
    forks_component = min(total_forks * 0.15, 15)
    prs_component = min(prs_merged * 0.25, 25)
    issues_component = min(issues_participated * 0.15, 15)
    age_component = min(account_age_months * 0.10, 10)
    
    raw_total = (stars_component + forks_component + 
                 prs_component + issues_component + 
                 age_component)
    
    # Velocity penalty for bursty accounts
    velocity_penalty = 0
    if activity_velocity > 200:
        velocity_penalty = min(
            (activity_velocity - 200) * 0.0015, 15
        )
    
    return max(0, round(raw_total - velocity_penalty))`}</pre>
        </div>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Impact Levels</h4>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {[
            { range: '0-34', level: 'Novice', color: 'text-slate-400' },
            { range: '35-54', level: 'Emerging', color: 'text-blue-400' },
            { range: '55-74', level: 'Active', color: 'text-cyan-400' },
            { range: '75-89', level: 'Strong', color: 'text-teal-400' },
            { range: '90-100', level: 'Elite', color: 'text-emerald-400' },
          ].map((b) => (
            <div key={b.level} className="rounded-lg border border-border bg-card p-3 text-center">
              <div className={`text-lg font-bold ${b.color}`}>{b.range}</div>
              <div className="text-xs text-foreground font-medium">{b.level}</div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 'botproof',
    icon: AlertTriangle,
    title: 'Bot-Proofing',
    content: (
      <div className="space-y-4">
        <p>Malicious actors cannot fake their score. All bot-proofing happens <strong>inside the Intelligent Contract</strong>, not client-side. A recruiter searching your GitHub username sees the contract's verdict, not your self-reported claims.</p>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Bot-Proofing Checks</h4>
        <div className="space-y-4">
          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-8 w-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center"><Clock className="h-4 w-4 text-primary" /></div>
              <div>
                <h5 className="font-semibold text-foreground text-sm">Account Age Gate</h5>
                <p className="text-xs text-muted-foreground">Minimum 1 month old</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">Accounts younger than 1 month are immediately rejected. This prevents throwaway accounts used for spam or fake reputation building.</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-8 w-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center"><TrendingUp className="h-4 w-4 text-primary" /></div>
              <div>
                <h5 className="font-semibold text-foreground text-sm">Activity Velocity</h5>
                <p className="text-xs text-muted-foreground">Detect bursty patterns</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">Accounts with {'>'}200 commits/month are flagged as potentially automated. A velocity penalty of up to 15 points is applied to the final score.</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-8 w-8 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center"><XCircle className="h-4 w-4 text-red-400" /></div>
              <div>
                <h5 className="font-semibold text-foreground text-sm">Invalid Handle Rejection</h5>
                <p className="text-xs text-muted-foreground">404 / 403 handling</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">Any handle returning HTTP 404 (not found) or 403 (rate limited) is immediately rejected with minimal gas cost.</p>
          </div>
        </div>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Bot Check Python Logic</h4>
        <div className="rounded-lg bg-secondary/50 border border-border p-4">
          <pre className="text-xs text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">{`def check_bot_proofing(account_age_months, activity_velocity):
    account_age_ok = account_age_months >= 1
    velocity_ok = activity_velocity <= 200
    
    if not account_age_ok:
        return {"passed": False, "reason": 
                f"Account age {account_age_months}mo < 1mo minimum"}
    if not velocity_ok:
        return {"passed": False, "reason": 
                f"Velocity {activity_velocity} suggests burst activity"}
    
    return {"passed": True, "reason": "All checks passed"}`}</pre>
        </div>
      </div>
    ),
  },
  {
    id: 'architecture',
    icon: Cpu,
    title: 'Contract Architecture',
    content: (
      <div className="space-y-4">
        <p>The <code>ImpactNotary</code> contract is written in Python for GenLayer's GenVM. It uses TreeMap storage and maintains a list of authorized verifiers.</p>
        <h4 className="font-semibold text-foreground mt-6 mb-2">ScoreRecord Storage</h4>
        <div className="rounded-lg bg-secondary/50 border border-border p-4 overflow-x-auto">
          <pre className="text-xs text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">{`@allow_storage
@dataclass
class ScoreRecord:
    github_username: str
    contribution_score: u32        # 0-100 weighted impact
    impact_level: str             # Novice|Emerging|Active|Strong|Elite
    repo_count: u32
    total_stars: u32
    total_forks: u32
    public_events: u32
    prs_merged: u32               # Weighted at 25%
    issues_participated: u32      # Weighted at 15%
    account_age_months: u32       # Bot-proofing + 10%
    activity_velocity: u32        # Bot-proofing check
    activity_velocity_flag: bool  # True if >200/mo
    key_strengths: str
    notable_repos: str
    notable_prs: list[PRRecord]   # At least 4 PRs
    activity_summary: str
    is_valid_user: bool
    error_reason: str
    verified_at: str
    verifier: str`}</pre>
        </div>
        <h4 className="font-semibold text-foreground mt-6 mb-2">Core Methods</h4>
        <ul className="space-y-3">
          {[
            { name: 'verify_github_user(username)', desc: 'Weighted scoring + bot-proofing + score-stability consensus' },
            { name: 'get_score(username)', desc: 'Fetch verified reputation with full breakdown' },
            { name: 'get_leaderboard(top_n)', desc: 'Return top valid users sorted by weighted score' },
            { name: 'get_all_scores()', desc: 'Return all stored records' },
            { name: 'add_verifier(address)', desc: 'Add authorized verifier (verifier-only)' },
          ].map((m) => (
            <li key={m.name} className="flex items-start gap-3"><Code className="h-4 w-4 text-primary mt-0.5 shrink-0" /><div><code className="text-sm font-mono text-foreground">{m.name}</code><p className="text-sm text-muted-foreground">{m.desc}</p></div></li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: 'consensus',
    icon: Shield,
    title: 'Consensus Mechanism',
    content: (
      <div className="space-y-4">
        <p>The consensus mechanism verifies that <strong>weighted scores + bot-proofing results</strong> are stable across all validators.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 my-6">
          {[
            { step: '1', title: 'PENDING', desc: 'Transaction submitted' },
            { step: '2', title: 'PROPOSING', desc: 'Leader runs weighted evaluate_user()' },
            { step: '3', title: 'COMMITTING', desc: 'Validators re-run same function' },
            { step: '4', title: 'REVEALING', desc: 'Weighted scores compared (±5 tol)' },
            { step: '5', title: 'ACCEPTED', desc: 'Majority agrees on stability' },
            { step: '6', title: 'FINALIZED', desc: 'Notarized on-chain permanently' },
          ].map((s) => (
            <div key={s.step} className="rounded-lg border border-border bg-card p-4">
              <div className="flex items-center gap-2 mb-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">{s.step}</span><span className="text-sm font-semibold text-foreground">{s.title}</span></div>
              <p className="text-xs text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Consensus Principle</h4>
        <div className="rounded-lg bg-secondary/50 border border-border p-4">
          <pre className="text-xs text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">{`result = gl.eq_principle.prompt_comparative(
    evaluate_user,
    principle="""
    For invalid users (is_valid_user=False), all must agree.
    For valid users, weighted contribution_score within 5 pts.
    impact_level must match. Bot-proofing results must match.
    prs_merged, issues_participated, account_age_months
    must match exactly since from same API.
    notable_prs list must contain semantically equivalent PRs.
    """
)`}</pre>
        </div>
      </div>
    ),
  },
  {
    id: 'genlayer',
    icon: Zap,
    title: 'GenLayer Integration',
    content: (
      <div className="space-y-4">
        <p>Impact Notary runs on the <strong>GenLayer Studio</strong> network. To connect your wallet, use the RPC auto-switch feature:</p>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Add GenLayer to Wallet (EIP-3085)</h4>
        <div className="rounded-lg bg-secondary/50 border border-border p-4">
          <pre className="text-xs text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">{`await window.ethereum.request({
  method: 'wallet_addEthereumChain',
  params: [{
    chainId: '0xF22F',  // Hex for 61999
    chainName: 'GenLayer Studio',
    rpcUrls: ['https://studio.genlayer.com/api'],
    nativeCurrency: {
      name: 'GEN',
      symbol: 'GEN',
      decimals: 18
    }
  }]
});`}</pre>
        </div>
        <h4 className="font-semibold text-foreground mt-4 mb-2">Notarization via writeContract</h4>
        <div className="rounded-lg bg-secondary/50 border border-border p-4">
          <pre className="text-xs text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">{`import { createClient } from 'genlayer-js';

const client = createClient({
  endpoint: 'https://studio.genlayer.com/api',
});

// Notarize a GitHub user's score
const txHash = await client.writeContract({
  address: contractAddress,
  functionName: "verify_github_user",
  args: ["torvalds"],
});

// Wait for consensus finalization
const receipt = await client.waitForTransactionReceipt({
  hash: txHash,
  status: "FINALIZED",
});

// Score is now permanently on-chain`}</pre>
        </div>
      </div>
    ),
  },
  {
    id: 'errors',
    icon: AlertTriangle,
    title: 'Error Handling',
    content: (
      <div className="space-y-4">
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-secondary/50 border-b border-border">
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Condition</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Contract Response</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase">Display</th>
              </tr>
            </thead>
            <tbody>
              {[
                { condition: 'GitHub 404', response: 'is_valid_user: False', display: 'User not found' },
                { condition: 'GitHub 403 (rate limit)', response: 'is_valid_user: False', display: 'API rate limit exceeded' },
                { condition: 'Account < 1 month', response: 'is_valid_user: False', display: 'Account too new (bot check)' },
                { condition: 'Velocity > 200/mo', response: 'velocity_flag: True', display: 'Bursty activity penalized' },
                { condition: 'Unauthorized caller', response: 'gl.UserError', display: 'Only verifiers can verify' },
                { condition: 'Consensus fail', response: 'UNDETERMINED', display: 'Validators disagreed — retry' },
              ].map((row, i) => (
                <tr key={row.condition} className={i % 2 === 0 ? 'bg-card' : 'bg-secondary/20'}>
                  <td className="px-4 py-3 text-foreground">{row.condition}</td>
                  <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{row.response}</td>
                  <td className="px-4 py-3 text-muted-foreground">{row.display}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    ),
  },
];

export default function Docs() {
  const [activeSection, setActiveSection] = useState('overview');
  const active = sections.find((s) => s.id === activeSection) || sections[0];

  return (
    <div className="pt-24 pb-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center"><BookOpen className="h-5 w-5 text-primary" /></div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground">Documentation</h1>
              <p className="text-muted-foreground text-sm mt-0.5">Learn how Impact Notary works under the hood</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }} className="lg:col-span-1">
            <div className="rounded-xl border border-border bg-card p-4 sticky top-24">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-3">Contents</h3>
              <nav className="space-y-1">
                {sections.map((s) => (
                  <button key={s.id} onClick={() => setActiveSection(s.id)} className={`w-full flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors text-left ${activeSection === s.id ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary'}`}>
                    <s.icon className="h-4 w-4 shrink-0" />{s.title}
                  </button>
                ))}
              </nav>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="lg:col-span-3">
            <div className="rounded-xl border border-border bg-card p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center"><active.icon className="h-5 w-5 text-primary" /></div>
                <h2 className="text-2xl font-bold text-foreground">{active.title}</h2>
              </div>
              <div className="prose prose-invert max-w-none">{active.content}</div>
            </div>

            <div className="mt-6 flex items-center justify-between">
              {sections.findIndex((s) => s.id === activeSection) > 0 && (
                <button onClick={() => { const idx = sections.findIndex((s) => s.id === activeSection); setActiveSection(sections[idx - 1].id); }} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Prev: {sections[sections.findIndex((s) => s.id === activeSection) - 1]?.title}
                </button>
              )}
              {sections.findIndex((s) => s.id === activeSection) < sections.length - 1 && (
                <button onClick={() => { const idx = sections.findIndex((s) => s.id === activeSection); setActiveSection(sections[idx + 1].id); }} className="ml-auto text-sm text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
                  Next: {sections[sections.findIndex((s) => s.id === activeSection) + 1]?.title}<ExternalLink className="h-3 w-3" />
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
