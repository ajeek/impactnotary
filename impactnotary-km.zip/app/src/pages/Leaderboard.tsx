import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Search, ArrowUpDown, Filter, Star, GitFork, GitPullRequest, MessageSquare, Clock, Shield } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { mockContract, getImpactColor, getScoreColor, getScoreBarColor } from '@/lib/mockData';
import type { ScoreRecord } from '@/types';

type SortField = 'contribution_score' | 'total_stars' | 'repo_count' | 'total_forks' | 'prs_merged' | 'issues_participated' | 'account_age_months';
type SortDir = 'asc' | 'desc';

export default function Leaderboard() {
  const [scores, setScores] = useState<ScoreRecord[]>([]);
  const [filtered, setFiltered] = useState<ScoreRecord[]>([]);
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<SortField>('contribution_score');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [levelFilter, setLevelFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    mockContract.getLeaderboard(50).then((data) => {
      setScores(data);
      setFiltered(data);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    let result = [...scores];
    if (search) {
      result = result.filter((s) => s.github_username.toLowerCase().includes(search.toLowerCase()));
    }
    if (levelFilter !== 'all') {
      result = result.filter((s) => s.impact_level === levelFilter);
    }
    result.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      return sortDir === 'desc' ? (bVal as number) - (aVal as number) : (aVal as number) - (bVal as number);
    });
    setFiltered(result);
  }, [scores, search, sortField, sortDir, levelFilter]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(sortDir === 'desc' ? 'asc' : 'desc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  const impactLevels = ['all', 'Elite', 'Strong', 'Active', 'Emerging', 'Novice'];

  return (
    <div className="pt-24 pb-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Trophy className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground">Leaderboard</h1>
              <p className="text-muted-foreground text-sm mt-0.5">Verified contributors ranked by weighted AI impact score</p>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search developers..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 bg-secondary/50" />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
            {impactLevels.map((level) => (
              <button key={level} onClick={() => setLevelFilter(level)} className={`rounded-full px-3 py-1.5 text-xs font-medium border transition-colors whitespace-nowrap ${levelFilter === level ? 'bg-primary/10 text-primary border-primary/30' : 'text-muted-foreground border-border hover:text-foreground'}`}>
                {level === 'all' ? 'All Levels' : level}
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="rounded-xl border border-border bg-card overflow-hidden">
          {/* Header */}
          <div className="grid grid-cols-12 gap-3 px-4 lg:px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider border-b border-border">
            <div className="col-span-1">Rank</div>
            <div className="col-span-3 lg:col-span-2">Developer</div>
            <div className="col-span-2 cursor-pointer flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort('contribution_score')}>
              Score <ArrowUpDown className="h-3 w-3" />
            </div>
            <div className="col-span-2 hidden sm:block">Level</div>
            <div className="col-span-2 hidden md:flex items-center gap-1 cursor-pointer hover:text-foreground" onClick={() => toggleSort('total_stars')}>
              <Star className="h-3 w-3" /> Stars
            </div>
            <div className="col-span-2 hidden lg:flex items-center gap-1 cursor-pointer hover:text-foreground" onClick={() => toggleSort('prs_merged')}>
              <GitPullRequest className="h-3 w-3" /> PRs
            </div>
            <div className="col-span-2 hidden xl:flex items-center gap-1 cursor-pointer hover:text-foreground" onClick={() => toggleSort('issues_participated')}>
              <MessageSquare className="h-3 w-3" /> Issues
            </div>
            <div className="col-span-4 sm:col-span-2 lg:col-span-1 text-right flex items-center justify-end gap-1 cursor-pointer hover:text-foreground" onClick={() => toggleSort('repo_count')}>
              <GitFork className="h-3 w-3" /> Repos
            </div>
          </div>

          {loading ? (
            <div className="py-20 text-center text-muted-foreground">Loading rankings...</div>
          ) : filtered.length === 0 ? (
            <div className="py-20 text-center text-muted-foreground">No developers match your filters.</div>
          ) : (
            filtered.map((dev, i) => (
              <motion.div
                key={dev.github_username}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="grid grid-cols-12 gap-3 px-4 lg:px-6 py-4 items-center border-b border-border/50 hover:bg-secondary/30 transition-colors"
              >
                <div className="col-span-1">
                  <span className={`inline-flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${i === 0 ? 'bg-yellow-500/10 text-yellow-500' : i === 1 ? 'bg-slate-300/10 text-slate-300' : i === 2 ? 'bg-amber-600/10 text-amber-600' : 'text-muted-foreground'}`}>
                    {i + 1}
                  </span>
                </div>
                <div className="col-span-3 lg:col-span-2 flex items-center gap-3 min-w-0">
                  <img
                    src={`https://github.com/${dev.github_username}.png?size=40`}
                    alt={dev.github_username}
                    className="h-8 w-8 rounded-full shrink-0"
                    onError={(e) => { (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${dev.github_username}&background=10b981&color=fff`; }}
                  />
                  <div className="min-w-0">
                    <span className="font-medium text-foreground truncate block text-sm">{dev.github_username}</span>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Clock className="h-2.5 w-2.5 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground">{dev.account_age_months}mo</span>
                      {dev.activity_velocity_flag && <Shield className="h-2.5 w-2.5 text-yellow-500" />}
                    </div>
                  </div>
                </div>
                <div className="col-span-2">
                  <div className="flex items-center gap-2">
                    <span className={`text-lg font-bold ${getScoreColor(dev.contribution_score)}`}>{dev.contribution_score}</span>
                    <div className="hidden sm:block h-1.5 w-12 rounded-full bg-secondary overflow-hidden">
                      <div className={`h-full rounded-full ${getScoreBarColor(dev.contribution_score)}`} style={{ width: `${dev.contribution_score}%` }} />
                    </div>
                  </div>
                </div>
                <div className="col-span-2 hidden sm:block">
                  <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${getImpactColor(dev.impact_level)}`}>{dev.impact_level}</span>
                </div>
                <div className="col-span-2 hidden md:block text-muted-foreground whitespace-nowrap text-sm">
                  {(dev.total_stars / 1000).toFixed(0)}K
                </div>
                <div className="col-span-2 hidden lg:block text-muted-foreground whitespace-nowrap text-sm">
                  {dev.prs_merged}
                </div>
                <div className="col-span-2 hidden xl:block text-muted-foreground whitespace-nowrap text-sm">
                  {dev.issues_participated}
                </div>
                <div className="col-span-4 sm:col-span-2 lg:col-span-1 text-right text-muted-foreground text-sm">
                  {dev.repo_count}
                </div>
              </motion.div>
            ))
          )}
        </motion.div>

        <div className="mt-4 text-xs text-muted-foreground text-center">
          Showing {filtered.length} of {scores.length} verified developers
        </div>

        {/* Scoring Formula Note */}
        <div className="mt-8 rounded-xl border border-primary/20 bg-primary/5 p-5">
          <h3 className="text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
            <Star className="h-4 w-4 text-primary" />
            Weighted Scoring Formula
          </h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            <strong>Score = (Stars x 0.35) + (Merged PRs x 0.25) + (Forks x 0.15) + (Issue Engagement x 0.15) + (Repo Age x 0.10)</strong> — 
            normalized to 0-100. Accounts with bursty activity (&gt;200 commits/mo) receive a velocity penalty. 
            Only accounts older than 1 month with organic patterns are accepted.
          </p>
        </div>
      </div>
    </div>
  );
}
