import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { motion } from 'framer-motion';
import { Shield, ArrowRight, Search, Cpu, GitPullRequest, MessageSquare, Clock, CheckCircle, Users, Star, Globe, Lock, Zap, AlertTriangle, TrendingUp, Activity } from 'lucide-react';
import { mockContract, getImpactColor, getScoreColor } from '@/lib/mockData';
import type { ScoreRecord } from '@/types';

const fadeInUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: 'easeOut' as const },
  }),
};

function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 lg:pt-40 lg:pb-28">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(16,185,129,0.15),transparent)]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-3xl mx-auto">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }} className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 mb-8">
            <Shield className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs font-medium text-primary">Weighted Reputation Verification</span>
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6 }} className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6">
            Verify Developer <span className="text-primary">Impact</span> On-Chain
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }} className="text-lg text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto">
            Not commits — real impact. Our Intelligent Contract applies a <strong>weighted scoring algorithm</strong> 
            (Stars 35% + PRs 25% + Forks 15% + Issues 15% + Age 10%) with built-in <strong>bot-proofing</strong> 
            and stores the result permanently via AI consensus.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.6 }} className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/verify" className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">
              <Search className="h-4 w-4" /> Verify a Developer <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/leaderboard" className="inline-flex items-center gap-2 rounded-lg border border-border bg-secondary px-6 py-3 text-sm font-semibold text-secondary-foreground hover:bg-secondary/80 transition-colors">
              <Activity className="h-4 w-4" /> View Leaderboard
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Stats() {
  const [stats, setStats] = useState({ verified: 0, validators: 0, avgScore: 0, totalPRs: 0 });

  useEffect(() => {
    async function load() {
      const scores = await mockContract.getAllScores();
      const verifiers = await mockContract.getVerifiers();
      const valid = scores.filter((s) => s.is_valid_user);
      setStats({
        verified: valid.length,
        validators: verifiers.length,
        avgScore: Math.round(valid.reduce((a, s) => a + s.contribution_score, 0) / valid.length) || 0,
        totalPRs: valid.reduce((a, s) => a + s.prs_merged, 0),
      });
    }
    load();
  }, []);

  const items = [
    { label: 'Developers Verified', value: stats.verified.toString(), icon: Users },
    { label: 'Consensus Validators', value: stats.validators.toString(), icon: Lock },
    { label: 'Avg Impact Score', value: stats.avgScore.toString(), icon: Star },
    { label: 'Total PRs Analyzed', value: `${(stats.totalPRs / 1000).toFixed(1)}K`, icon: GitPullRequest },
  ];

  return (
    <section className="py-16 border-y border-border/50 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, i) => (
            <motion.div key={item.label} custom={i} variants={fadeInUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center">
              <div className="inline-flex items-center justify-center h-10 w-10 rounded-lg bg-primary/10 border border-primary/20 mb-3">
                <item.icon className="h-5 w-5 text-primary" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">{item.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{item.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ScoringAlgorithm() {
  const weights = [
    { factor: 'Stars', weight: '35%', icon: Star, desc: 'Public validation: are others using their code?', color: 'text-yellow-400' },
    { factor: 'Merged PRs', weight: '25%', icon: GitPullRequest, desc: 'Collaborative quality over raw commit count', color: 'text-emerald-400' },
    { factor: 'Forks', weight: '15%', icon: Globe, desc: 'Are others building on their work?', color: 'text-blue-400' },
    { factor: 'Issue Engagement', weight: '15%', icon: MessageSquare, desc: 'Resolution time and discussion participation', color: 'text-purple-400' },
    { factor: 'Repo Age Factor', weight: '10%', icon: Clock, desc: 'Long-term consistency and sustained impact', color: 'text-cyan-400' },
  ];

  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-foreground mb-4">Weighted Scoring Algorithm</h2>
          <p className="text-muted-foreground">We avoid naive "repo counting." Each metric is weighted based on its signal quality for real developer impact.</p>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {weights.map((w, i) => (
            <motion.div key={w.factor} custom={i} variants={fadeInUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="rounded-xl border border-border bg-card p-6 text-center hover:border-primary/30 transition-colors">
              <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 border border-primary/20 mb-4 mx-auto">
                <w.icon className="h-6 w-6 text-primary" />
              </div>
              <div className={`text-2xl font-bold ${w.color} mb-1`}>{w.weight}</div>
              <h3 className="font-semibold text-foreground mb-1">{w.factor}</h3>
              <p className="text-xs text-muted-foreground">{w.desc}</p>
            </motion.div>
          ))}
        </div>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.3 }} className="mt-10 rounded-xl border border-primary/20 bg-primary/5 p-6 text-center">
          <p className="text-sm text-muted-foreground">
            <strong className="text-foreground">Formula:</strong> Score = (Stars x 0.35) + (Merged PRs x 0.25) + (Forks x 0.15) + (Issues x 0.15) + (Age x 0.10), normalized 0-100
          </p>
        </motion.div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { icon: Search, title: 'Fetch GitHub Data', description: 'The Intelligent Contract fetches public repos, stars, forks, merged PRs, issue engagement, and activity data directly from GitHub API.' },
    { icon: Cpu, title: 'Weighted AI Analysis', description: 'A single unified LLM prompt applies the weighted scoring formula: Stars 35%, PRs 25%, Forks 15%, Issues 15%, Age 10%.' },
    { icon: AlertTriangle, title: 'Bot-Proofing Check', description: 'Account age must be >1 month. Activity velocity is analyzed for organic patterns. Bursty accounts (>200 commits/mo) are flagged and penalized.' },
    { icon: Lock, title: 'Validator Consensus', description: 'Multiple validators re-run the same evaluation. Consensus reached when weighted scores agree within ±5 points. Stored permanently on-chain.' },
  ];

  return (
    <section className="py-24 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-foreground mb-4">How It Works</h2>
          <p className="text-muted-foreground">A four-step process that turns GitHub activity into a decentralized, trustless reputation score through weighted AI consensus.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, i) => (
            <motion.div key={step.title} custom={i} variants={fadeInUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="relative group">
              <div className="rounded-xl border border-border bg-card p-6 h-full hover:border-primary/30 transition-colors">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 border border-primary/20 mb-5">
                  <step.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">{i + 1}</span>
                  <h3 className="font-semibold text-foreground">{step.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                  <ArrowRight className="h-4 w-4 text-muted-foreground/30" />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function LeaderboardPreview() {
  const [leaders, setLeaders] = useState<ScoreRecord[]>([]);

  useEffect(() => {
    mockContract.getLeaderboard(5).then(setLeaders);
  }, []);

  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-10">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl font-bold tracking-tight text-foreground mb-2">Top Contributors</h2>
            <p className="text-muted-foreground">The highest impact developers verified by weighted AI consensus</p>
          </motion.div>
          <Link to="/leaderboard" className="hidden sm:inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            View All <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="grid grid-cols-12 gap-4 px-6 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider border-b border-border">
            <div className="col-span-1">Rank</div>
            <div className="col-span-4 sm:col-span-3">Developer</div>
            <div className="col-span-3 sm:col-span-2">Score</div>
            <div className="col-span-2 hidden sm:block">Level</div>
            <div className="col-span-2 hidden md:block">Stars</div>
            <div className="col-span-2 hidden lg:block">PRs</div>
            <div className="col-span-4 sm:col-span-2 text-right">Repos</div>
          </div>

          {leaders.map((dev, i) => (
            <motion.div
              key={dev.github_username}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="grid grid-cols-12 gap-4 px-6 py-4 items-center border-b border-border/50 hover:bg-secondary/30 transition-colors"
            >
              <div className="col-span-1">
                <span className={`inline-flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${i === 0 ? 'bg-yellow-500/10 text-yellow-500' : i === 1 ? 'bg-slate-300/10 text-slate-300' : i === 2 ? 'bg-amber-600/10 text-amber-600' : 'text-muted-foreground'}`}>
                  {i + 1}
                </span>
              </div>
              <div className="col-span-4 sm:col-span-3 flex items-center gap-3">
                <img src={`https://github.com/${dev.github_username}.png?size=40`} alt={dev.github_username} className="h-8 w-8 rounded-full" onError={(e) => { (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${dev.github_username}&background=10b981&color=fff`; }} />
                <span className="font-medium text-foreground truncate">{dev.github_username}</span>
              </div>
              <div className="col-span-3 sm:col-span-2">
                <span className={`text-lg font-bold ${getScoreColor(dev.contribution_score)}`}>{dev.contribution_score}</span>
              </div>
              <div className="col-span-2 hidden sm:block">
                <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${getImpactColor(dev.impact_level)}`}>{dev.impact_level}</span>
              </div>
              <div className="col-span-2 hidden md:block text-muted-foreground whitespace-nowrap">{(dev.total_stars / 1000).toFixed(0)}K</div>
              <div className="col-span-2 hidden lg:block text-muted-foreground">{dev.prs_merged}</div>
              <div className="col-span-4 sm:col-span-2 text-right text-muted-foreground">{dev.repo_count}</div>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 text-center sm:hidden">
          <Link to="/leaderboard" className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            View All Rankings <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function BotProofingSection() {
  const checks = [
    { icon: Clock, title: 'Account Age Gate', desc: 'Only accounts > 1 month old are accepted. Fresh accounts are rejected as potential spam.' },
    { icon: TrendingUp, title: 'Activity Velocity', desc: 'Organic commit patterns required. Accounts with >200 commits/month bursts are flagged and penalized.' },
    { icon: AlertTriangle, title: '404/403 Rejection', desc: 'Invalid handles, rate-limited requests, and non-existent users are immediately rejected before scoring.' },
    { icon: Lock, title: 'Validator Re-execution', desc: 'Every validator re-runs the exact same evaluation function. No client-side trust — all checks happen on-chain.' },
  ];

  return (
    <section className="py-24 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-foreground mb-4">Bot-Proofing Layer</h2>
          <p className="text-muted-foreground">Malicious actors cannot fake their score. All verification happens inside the Intelligent Contract, not on the client.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {checks.map((check, i) => (
            <motion.div key={check.title} custom={i} variants={fadeInUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="rounded-xl border border-border bg-card p-6 flex gap-4 hover:border-primary/30 transition-colors">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
                <check.icon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">{check.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{check.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ConsensusDiagram() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-foreground mb-4">Score Stability Consensus</h2>
          <p className="text-muted-foreground">All validators run the same weighted evaluation on the same data. Consensus is reached when scores agree within ±5 points.</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                <Search className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Leader Node</h3>
                <p className="text-xs text-muted-foreground">Executes weighted evaluation first</p>
              </div>
            </div>
            <ul className="space-y-3">
              {['Fetches GitHub profile + repos + PRs', 'Applies weighted scoring formula', 'Runs bot-proofing checks', 'Produces initial weighted score'].map((item) => (
                <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground"><CheckCircle className="h-4 w-4 text-primary shrink-0" />{item}</li>
              ))}
            </ul>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="flex flex-col items-center gap-4">
            <div className="hidden lg:flex flex-col items-center gap-2">
              <div className="h-12 w-px bg-border" />
              <div className="flex items-center gap-2 rounded-full bg-primary/10 border border-primary/20 px-4 py-2">
                <Zap className="h-4 w-4 text-primary" />
                <span className="text-xs font-medium text-primary">Consensus Check</span>
              </div>
              <div className="h-12 w-px bg-border" />
            </div>
            <div className="lg:hidden flex items-center gap-4">
              <div className="w-12 h-px bg-border" />
              <div className="flex items-center gap-2 rounded-full bg-primary/10 border border-primary/20 px-4 py-2">
                <Zap className="h-4 w-4 text-primary" />
                <span className="text-xs font-medium text-primary">Consensus</span>
              </div>
              <div className="w-12 h-px bg-border" />
            </div>
            <div className="rounded-lg bg-secondary border border-border px-4 py-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Tolerance Threshold</p>
              <p className="text-lg font-bold text-primary">Weighted ±5 Points</p>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Validator Pool</h3>
                <p className="text-xs text-muted-foreground">Re-executes and votes on result</p>
              </div>
            </div>
            <ul className="space-y-3">
              {['Re-run same weighted evaluation', 'Compare bot-proofing results', 'Check score within ±5 tolerance', 'Vote agree / disagree on result'].map((item) => (
                <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground"><CheckCircle className="h-4 w-4 text-primary shrink-0" />{item}</li>
              ))}
            </ul>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mt-10 rounded-xl border border-primary/20 bg-primary/5 p-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Lock className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-foreground">Finalized On-Chain</h3>
          </div>
          <p className="text-sm text-muted-foreground max-w-lg mx-auto">
            Once majority validators agree, the weighted score + bot-proofing results + notable PRs are permanently stored in the contract's TreeMap storage.
          </p>
        </motion.div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="relative overflow-hidden rounded-2xl border border-border bg-card p-8 sm:p-12 text-center">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_50%_50%,rgba(16,185,129,0.1),transparent)]" />
          <div className="relative">
            <h2 className="text-3xl font-bold tracking-tight text-foreground mb-4">Ready to Verify Impact?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto mb-8">
              Search any GitHub username for public verification. No OAuth required — just real, weighted, on-chain reputation proof.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/verify" className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">
                <Search className="h-4 w-4" /> Verify Now
              </Link>
              <Link to="/docs" className="inline-flex items-center gap-2 rounded-lg border border-border px-6 py-3 text-sm font-semibold text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                <Shield className="h-4 w-4" /> Learn More
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <div>
      <Hero />
      <Stats />
      <ScoringAlgorithm />
      <HowItWorks />
      <BotProofingSection />
      <LeaderboardPreview />
      <ConsensusDiagram />
      <CTASection />
    </div>
  );
}
