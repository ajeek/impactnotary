import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Shield, CheckCircle, XCircle, Loader2, Star, GitFork, Activity,
  GitBranch, User, Calendar, Zap, ArrowRight, AlertTriangle, Clock,
  GitPullRequest, MessageSquare, TrendingUp, Link2
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { mockContract, getImpactColor, getScoreColor, getVelocityColor, getVelocityLabel } from '@/lib/mockData';
import type { ScoreRecord, VerificationStatus } from '@/types';

function ScoreBreakdownCard({ record }: { record: ScoreRecord }) {
  const maxStars = Math.min(record.total_stars * 0.35, 35);
  const maxForks = Math.min(record.total_forks * 0.15, 15);
  const maxPRs = Math.min(record.prs_merged * 0.25, 25);
  const maxIssues = Math.min(record.issues_participated * 0.15, 15);
  const maxAge = Math.min(record.account_age_months * 0.10, 10);

  const metrics = [
    { label: 'Stars', icon: Star, weight: '35%', value: maxStars.toFixed(1), max: 35, color: 'bg-yellow-500', raw: record.total_stars >= 1000 ? `${(record.total_stars / 1000).toFixed(0)}K` : record.total_stars.toString() },
    { label: 'Merged PRs', icon: GitPullRequest, weight: '25%', value: maxPRs.toFixed(1), max: 25, color: 'bg-emerald-500', raw: record.prs_merged.toString() },
    { label: 'Forks', icon: GitFork, weight: '15%', value: maxForks.toFixed(1), max: 15, color: 'bg-blue-500', raw: record.total_forks >= 1000 ? `${(record.total_forks / 1000).toFixed(0)}K` : record.total_forks.toString() },
    { label: 'Issue Engagement', icon: MessageSquare, weight: '15%', value: maxIssues.toFixed(1), max: 15, color: 'bg-purple-500', raw: record.issues_participated.toString() },
    { label: 'Repo Age Factor', icon: Clock, weight: '10%', value: maxAge.toFixed(1), max: 10, color: 'bg-cyan-500', raw: `${record.account_age_months}mo` },
  ];

  return (
    <div className="rounded-lg border border-border bg-secondary/30 p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
        <TrendingUp className="h-4 w-4 text-primary" />
        Weighted Score Breakdown
      </h3>
      <div className="space-y-3">
        {metrics.map((m) => (
          <div key={m.label} className="flex items-center gap-3">
            <m.icon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <div className="w-28 sm:w-32 shrink-0">
              <div className="text-xs text-foreground font-medium">{m.label}</div>
              <div className="text-[10px] text-muted-foreground">Weight: {m.weight}</div>
            </div>
            <div className="flex-1 h-2 rounded-full bg-secondary overflow-hidden">
              <div className={`h-full rounded-full ${m.color}`} style={{ width: `${(parseFloat(m.value) / m.max) * 100}%` }} />
            </div>
            <div className="w-16 text-right shrink-0">
              <span className="text-xs font-bold text-foreground">+{m.value}</span>
              <span className="text-[10px] text-muted-foreground ml-1">({m.raw})</span>
            </div>
          </div>
        ))}
      </div>
      {record.activity_velocity_flag && (
        <div className="mt-4 flex items-center gap-2 rounded-lg border border-red-500/20 bg-red-500/10 px-3 py-2 text-xs text-red-400">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          Velocity penalty applied: {record.activity_velocity} commits/mo exceeds threshold
        </div>
      )}
    </div>
  );
}

function BotCheckCard({ record }: { record: ScoreRecord }) {
  const ageOk = record.account_age_months >= 1;
  const velOk = record.activity_velocity <= 200;

  return (
    <div className="rounded-lg border border-border bg-secondary/30 p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
        <Shield className="h-4 w-4 text-primary" />
        Bot-Proofing Checks
      </h3>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Account Age &gt; 1 month</span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-xs font-medium ${ageOk ? 'text-emerald-400' : 'text-red-400'}`}>
              {record.account_age_months}mo
            </span>
            {ageOk ? <CheckCircle className="h-3.5 w-3.5 text-emerald-400" /> : <XCircle className="h-3.5 w-3.5 text-red-400" />}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Activity Velocity</span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-xs font-medium ${velOk ? 'text-emerald-400' : 'text-red-400'}`}>
              {record.activity_velocity}/mo
            </span>
            {velOk ? <CheckCircle className="h-3.5 w-3.5 text-emerald-400" /> : <AlertTriangle className="h-3.5 w-3.5 text-yellow-400" />}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Velocity Label</span>
          </div>
          <span className={`text-xs font-medium ${getVelocityColor(record.activity_velocity)}`}>
            {getVelocityLabel(record.activity_velocity)}
          </span>
        </div>
      </div>
    </div>
  );
}

function NotablePRsCard({ record }: { record: ScoreRecord }) {
  const prs = record.notable_prs;
  if (!prs || prs.length === 0) return null;

  return (
    <div className="rounded-lg border border-border bg-secondary/30 p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
        <GitPullRequest className="h-4 w-4 text-primary" />
        Notable Pull Requests ({prs.length})
      </h3>
      <div className="space-y-3">
        {prs.map((pr, i) => (
          <motion.div
            key={`${pr.repo_name}-${i}`}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-lg border border-border bg-card p-4 hover:border-primary/20 transition-colors"
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="inline-flex items-center rounded-full bg-primary/10 border border-primary/20 px-2 py-0.5 text-[10px] font-medium text-primary">
                    {pr.impact_tag}
                  </span>
                  <span className="text-[10px] text-muted-foreground font-mono flex items-center gap-1">
                    <GitBranch className="h-3 w-3" />
                    {pr.repo_name}
                  </span>
                </div>
                <h4 className="text-sm font-semibold text-foreground truncate">{pr.title}</h4>
              </div>
              <span className="text-[10px] text-muted-foreground shrink-0">{pr.merged_at}</span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed mb-2">{pr.description}</p>
            <div className="flex items-center gap-3 text-[10px] text-muted-foreground font-mono">
              <span className="text-emerald-400">+{pr.additions.toLocaleString()}</span>
              <span className="text-red-400">-{pr.deletions.toLocaleString()}</span>
              <span>{((pr.additions + pr.deletions) / 1000).toFixed(1)}K lines</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default function Verify() {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ScoreRecord | null>(null);
  const [status, setStatus] = useState<VerificationStatus | null>(null);
  const [error, setError] = useState('');

  const simulateConsensus = async (targetScore: number) => {
    const stages: VerificationStatus[] = [
      { status: 'pending', message: 'Submitting transaction to GenLayer...', progress: 10 },
      { status: 'proposing', message: 'Leader selected, fetching GitHub profile + repos + events...', progress: 25 },
      { status: 'committing', message: 'Running weighted scoring algorithm (Stars 0.35 + PRs 0.25 + Forks 0.15 + Issues 0.15 + Age 0.10)...', progress: 45 },
      { status: 'committing', message: 'Bot-proofing checks: account age, activity velocity, organic pattern analysis...', progress: 60 },
      { status: 'revealing', message: `Validators comparing weighted scores (target: ${targetScore}) within ±5 tolerance...`, progress: 75 },
      { status: 'accepted', message: 'Consensus reached! All validators agree within threshold.', progress: 90 },
      { status: 'finalized', message: 'Score permanently notarized on-chain via TreeMap storage.', progress: 100 },
    ];

    for (const stage of stages) {
      setStatus(stage);
      await new Promise((r) => setTimeout(r, 900));
    }
  };

  const handleVerify = async () => {
    if (!username.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    setStatus({ status: 'pending', message: 'Starting on-chain verification...', progress: 0 });

    try {
      const isValid = await mockContract.validateGitHubUser(username);
      if (!isValid) {
        setError('Invalid GitHub username. Please check the spelling and try again.');
        setStatus(null);
        setLoading(false);
        return;
      }

      const existing = await mockContract.getScore(username);
      if (existing) {
        setResult(existing);
        setStatus({ status: 'finalized', message: 'Score already notarized on-chain.', progress: 100 });
        setLoading(false);
        return;
      }

      const newScore = await mockContract.verifyGitHubUser(username);
      await simulateConsensus(newScore.contribution_score);
      setResult(newScore);
    } catch {
      setError('Verification failed. Please try again.');
      setStatus(null);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleVerify();
  };

  return (
    <div className="pt-24 pb-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-xl bg-primary/10 border border-primary/20 mb-4">
            <Shield className="h-6 w-6 text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground mb-3">Verify GitHub Developer</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Enter any GitHub username for public verification. Our Intelligent Contract applies 
            weighted scoring and bot-proofing checks through AI consensus.
          </p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-xl border border-border bg-card p-6 mb-8">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Enter any GitHub username (e.g. torvalds)" value={username} onChange={(e) => setUsername(e.target.value)} onKeyDown={handleKeyDown} className="pl-10 bg-secondary/50" />
            </div>
            <Button onClick={handleVerify} disabled={loading || !username.trim()} className="bg-primary hover:bg-primary/90 text-primary-foreground shrink-0">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Search className="h-4 w-4 mr-2" />Verify</>}
            </Button>
          </div>
          {error && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 flex items-center gap-2 rounded-lg border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-400">
              <XCircle className="h-4 w-4 shrink-0" /> {error}
            </motion.div>
          )}
        </motion.div>

        <AnimatePresence>
          {status && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-8">
              <div className="rounded-xl border border-border bg-card p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    {status.status === 'finalized' || status.status === 'accepted' ? <CheckCircle className="h-5 w-5 text-primary" /> : status.status === 'error' ? <XCircle className="h-5 w-5 text-red-400" /> : <Loader2 className="h-5 w-5 text-primary animate-spin" />}
                    <span className="text-sm font-medium text-foreground capitalize">{status.status}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{status.progress}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-secondary overflow-hidden mb-3">
                  <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${status.progress}%` }} transition={{ duration: 0.5 }} />
                </div>
                <p className="text-sm text-muted-foreground">{status.message}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {result && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
              {/* Score Header */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="p-6 border-b border-border">
                  <div className="flex items-start gap-4">
                    <img src={`https://github.com/${result.github_username}.png?size=80`} alt={result.github_username} className="h-16 w-16 rounded-full" onError={(e) => { (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${result.github_username}&background=10b981&color=fff&size=80`; }} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h2 className="text-xl font-bold text-foreground">{result.github_username}</h2>
                        <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${getImpactColor(result.impact_level)}`}>{result.impact_level}</span>
                        {result.is_valid_user ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 border border-primary/20 px-2 py-0.5 text-xs font-medium text-primary"><CheckCircle className="h-3 w-3" />Verified</span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-red-500/10 border border-red-500/20 px-2 py-0.5 text-xs font-medium text-red-400"><XCircle className="h-3 w-3" />Bot Rejected</span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{result.activity_summary}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className={`text-4xl font-bold ${getScoreColor(result.contribution_score)}`}>{result.contribution_score}</div>
                      <div className="text-xs text-muted-foreground">Impact Score</div>
                    </div>
                  </div>
                </div>

                {result.is_valid_user && (
                  <>
                    {/* Stats Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 p-6 border-b border-border">
                      {[
                        { icon: GitBranch, label: 'Repos', value: result.repo_count },
                        { icon: Star, label: 'Stars', value: result.total_stars >= 1000 ? `${(result.total_stars / 1000).toFixed(1)}K` : result.total_stars },
                        { icon: GitFork, label: 'Forks', value: result.total_forks >= 1000 ? `${(result.total_forks / 1000).toFixed(1)}K` : result.total_forks },
                        { icon: GitPullRequest, label: 'PRs Merged', value: result.prs_merged },
                        { icon: MessageSquare, label: 'Issues', value: result.issues_participated },
                        { icon: Activity, label: 'Events', value: result.public_events },
                      ].map((s) => (
                        <div key={s.label} className="text-center">
                          <div className="flex items-center justify-center gap-1.5 mb-1">
                            <s.icon className="h-3.5 w-3.5 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{s.label}</span>
                          </div>
                          <div className="text-lg font-bold text-foreground">{s.value}</div>
                        </div>
                      ))}
                    </div>

                    {/* Score Breakdown + Bot Checks */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-6 border-b border-border">
                      <ScoreBreakdownCard record={result} />
                      <BotCheckCard record={result} />
                    </div>

                    {/* Key Strengths */}
                    <div className="p-6 border-b border-border">
                      <div className="flex items-center gap-2 mb-3">
                        <Zap className="h-4 w-4 text-primary" />
                        <h3 className="font-semibold text-foreground">Key Strengths</h3>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {result.key_strengths.split(',').map((s) => (
                          <span key={s} className="inline-flex items-center rounded-full bg-primary/10 border border-primary/20 px-3 py-1 text-xs font-medium text-primary">{s.trim()}</span>
                        ))}
                      </div>
                    </div>

                    {/* Notable Repos */}
                    {result.notable_repos && (
                      <div className="p-6 border-b border-border">
                        <div className="flex items-center gap-2 mb-3">
                          <Star className="h-4 w-4 text-primary" />
                          <h3 className="font-semibold text-foreground">Notable Repositories</h3>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {result.notable_repos.split(',').map((r) => (
                            <a key={r} href={`https://github.com/${result.github_username}/${r.trim()}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary px-3 py-1.5 text-sm text-foreground hover:border-primary/30 transition-colors">
                              <Link2 className="h-3.5 w-3.5 text-muted-foreground" />{r.trim()}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* On-chain Metadata */}
                <div className="p-6 bg-secondary/30">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" />{new Date(result.verified_at).toLocaleDateString()}</span>
                      <span className="flex items-center gap-1.5 font-mono"><Shield className="h-3.5 w-3.5" />{result.verifier.slice(0, 18)}...</span>
                    </div>
                    <a href={`https://github.com/${result.github_username}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                      View on GitHub <ArrowRight className="h-3.5 w-3.5" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Notable PRs - Outside card for full width */}
              {result.is_valid_user && <NotablePRsCard record={result} />}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
